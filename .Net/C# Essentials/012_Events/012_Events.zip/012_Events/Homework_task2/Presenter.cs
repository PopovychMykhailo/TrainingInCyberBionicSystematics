﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Homework_task2
{
    public class Presenter
    {
        private Model model;
        private View view;

        public Presenter()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Heandler event
        /// </summary>
        private void mainWindow_myEvent()
        {
            throw new System.NotImplementedException();
        }
    }
}