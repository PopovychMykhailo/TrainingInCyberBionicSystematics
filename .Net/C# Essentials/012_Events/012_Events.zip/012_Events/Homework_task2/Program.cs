﻿using System;

namespace Homework_task2
{
    /* Technical task
    
        Используя Visual Studio, создайте проект по шаблону Console Application.
        Используя конструктор диаграмм классов DSL, создайте общую диаграмму классов для паттерна MVP
        (Model-View-Presenter)
    */


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
