﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Homework_task2
{
    public class View
    {
        private EventHandler myEvent;

        public EventHandler MyEvent
        {
            get => default;
            set
            {
            }
        }

        public void MainWindow()
        {
            throw new System.NotImplementedException();
        }

        /// <summary></summary>
        private void button1_Click()
        {
            throw new System.NotImplementedException();
        }
    }
}