﻿// Model

namespace MVP
{
    class Model
    {
        public string Logic(string s)
        {
            return string.Format("Работа: Model.Logic({0})", s);
        }
    }
}
