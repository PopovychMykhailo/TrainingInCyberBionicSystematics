﻿using System;

namespace MyNamespace
{
    public class MyClass
    {
        public void Method()
        {
            Console.WriteLine($"Hello world, from {GetType()}!");
        }
    }
}
