﻿using System;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string userWord;
            string resultWord = "(empty)";
            bool error = false;

            Console.Write("Please enter a word about weather: ");
            userWord = Console.ReadLine().ToLower();

            switch (userWord)
            {
                case "sunny":
                    {
                        resultWord = "Солнечно";
                        break;
                    }

                case "cloudy":
                    {
                        resultWord = "Облачно";
                        break;
                    }

                case "damp":
                    {
                        resultWord = "Влажно";
                        break;
                    }

                case "rain":
                    {
                        resultWord = "Дождь";
                        break;
                    }

                case "snow":
                    {
                        resultWord = "Снег";
                        break;
                    }

                case "fog":
                    {
                        resultWord = "Туман";
                        break;
                    }

                case "windy":
                    {
                        resultWord = "Ветренно";
                        break;
                    }

                case "cold":
                    {
                        resultWord = "Холодно";
                        break;
                    }

                case "hot":
                    {
                        resultWord = "Жарко";
                        break;
                    }

                case "nice weather":
                    {
                        resultWord = "Отличная погода)";
                        break;
                    }

                default:
                    {
                        Console.WriteLine("I don't know the word, please enter another word)");

                        error = true;
                        break;
                    }
            }

            if (error == false)
            {
                Console.WriteLine("The word is translated to russian: " + resultWord);
            }
        }
    }
}
