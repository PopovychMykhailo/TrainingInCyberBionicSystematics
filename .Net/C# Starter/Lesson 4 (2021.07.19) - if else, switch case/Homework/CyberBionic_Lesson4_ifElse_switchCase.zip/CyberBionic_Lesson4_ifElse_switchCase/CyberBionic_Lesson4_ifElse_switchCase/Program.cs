﻿using System;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal operand1 = 0;
            decimal operand2 = 0;
            decimal result = 0;
            bool error = false;
            string sign;


            Console.Write("Please enter first operand: ");
            operand1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter second operand: ");
            operand2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter sign (+, -, *, /): ");
            sign = Console.ReadLine();


            switch (sign)
            {
                // Прибавление
                case "+":
                    {
                        result = operand1 + operand2;
                        break;
                    }

                // Отнимание
                case "-":
                    {
                        result = operand1 - operand2;
                        break;
                    }

                // Умножение
                case "*":
                    {
                        result = operand1 * operand2;
                        break;
                    }

                // Деление
                case "/":
                    {
                        if (operand2 != 0)
                        {
                            result = operand1 / operand2;
                        }
                        else
                        {
                            Console.WriteLine("Division by 0 is prohibited! Try enter sign again.");
                            error = true;
                        }

                        break;
                    }

                default:
                    {
                        Console.WriteLine("Unknown sign! Try enter sign again.");
                        error = true;

                        break;
                    }
            }

            if (error == false)
            {
                Console.WriteLine("Result: " + operand1 + " " + sign + " " + operand2 + " = " + result);
            }
        }
    }
}
