﻿using System;

namespace Task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int value;


            Console.Write("Please enter the value: ");
            value = Convert.ToInt32(Console.ReadLine());

            if (value >= 0 && value <= 14)
            {
                Console.WriteLine("The number ranges from 0 to 14");
            }
            else if (value >= 15 && value <= 35)
            {
                Console.WriteLine("The number ranges from 15 to 35");
            }
            else if (value >= 36 && value <= 50)
            {
                Console.WriteLine("The number ranges from 36 to 50");
            }
            else if (value >= 50 && value <= 100)
            {
                Console.WriteLine("The number ranges from 50 to 100");
            }
            else
            {
                Console.WriteLine("The number out of range 0-100");
            }
        }
    }
}
